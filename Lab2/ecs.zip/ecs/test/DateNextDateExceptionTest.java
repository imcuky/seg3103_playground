public class DateNextDateExceptionTest
{


}